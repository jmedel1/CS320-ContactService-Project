import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

// This class tests the ContactService class
public class ContactServiceTest {

    // This test checks if a new contact can be added
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact elmo = new Contact("E458", "Elmo", "Monster", "2125556789", "150th Sesame Street");

        assertTrue(service.addContact(elmo));  // should add successfully
        assertFalse(service.addContact(elmo)); // should not add again (duplicate)
    }
    
    // This test checks if we can delete a contact
    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact dora = new Contact("D456", "Dora", "Explora", "5512345678", "5 Jungle Trail");

        service.addContact(dora); // first adding Dora

        assertTrue(service.deleteContact("D456")); // should delete successfully
        assertFalse(service.deleteContact("D456")); // should not delete again (already gone)
    }
    
    // This test checks if a contact can be updated
    @Test
    public void testUpdateContact() {
        ContactService service = new ContactService();
        Contact dora = new Contact("D456", "Dora", "Explora", "5512345678", "5 Jungle Trail");

        service.addContact(dora); // first adding Dora

        // Updating Dora into Swiper
        assertTrue(service.updateContact("D456", "Swiper", "Fox", "3318815723", "99 Sneaky Ln"));

        // Making sure the updates worked
        assertEquals("Swiper", dora.getFirstName());
        assertEquals("Fox", dora.getLastName());
        assertEquals("3318815723", dora.getPhone());
        assertEquals("99 Sneaky Ln", dora.getAddress());

        // Updating a non-existing contact should fail
        assertFalse(service.updateContact("X999", "Test", "User", "0000000000", "Nowhere"));
    }
}