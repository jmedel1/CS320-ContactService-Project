// This class is for making a Contact
public class Contact {
private String contactId; // unique id for the contact (cannot change later)
private String firstName; // first name of the contact
private String lastName; // last name of the contact
private String phone; // phone number (should be 10 digits)
private String address; // address (should be 30 characters or less)

//This creates a new Contact with all the details
public Contact(String contactId, String firstName, String lastName, String phone, String address) {
	
	// Contact ID must not be null and max 10 characters
    if (contactId == null || contactId.length() > 10) {
        throw new IllegalArgumentException("Contact ID must not be null and cannot be longer than 10 characters");
    }
    
 // First name must not be null and max 10 characters
    if (firstName == null || firstName.length() > 10) {
        throw new IllegalArgumentException("First name must not be null and cannot be longer than 10 characters");
    }
    
 // Last name must not be null and max 10 characters
    if (lastName == null || lastName.length() > 10) {
        throw new IllegalArgumentException("Last name must not be null and cannot be longer than 10 characters");
    }
    
    // Phone number must be 10 digits and not null
    if (phone == null || phone.length() != 10) {
        throw new IllegalArgumentException("Phone number must be 10 digits");
    }
    
 // Address must not be null and max 30 characters
    if (address == null || address.length() > 30) {
        throw new IllegalArgumentException("Address must not be null and cannot be longer than 30 characters");
    }
    
	this.contactId = contactId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phone = phone;
	this.address = address;
}

//Getters to look at the information
public String getContactId() {
	return contactId;
}

public String getFirstName() {
	return firstName;
}

public String getLastName() {
	return lastName;
}

public String getPhone() {
	return phone;
}

public String getAddress() {
	return address;
}

//Setters to change the information
// Cannot change contactId
public void setFirstName(String firstName) {
	if (firstName == null || firstName.length() > 10) {
        throw new IllegalArgumentException("First name must not be null and cannot be longer than 10 characters");
    }
	this.firstName = firstName;
}

public void setLastName(String lastName) {
	if (lastName == null || lastName.length() > 10) {
        throw new IllegalArgumentException("Last name must not be null and cannot be longer than 10 characters");
    }
	this.lastName = lastName;
}

public void setPhone(String phone) {
	    if (phone == null || phone.length() != 10) {
	        throw new IllegalArgumentException("Phone number must be 10 digits");
	    }
	this.phone = phone;
}

public void setAddress(String address) {
	if (address == null || address.length() > 30) {
        throw new IllegalArgumentException("Address must not be null and cannot be longer than 30 characters");
    }
	this.address = address;
}

}
