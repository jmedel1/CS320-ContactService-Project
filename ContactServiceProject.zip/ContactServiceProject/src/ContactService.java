import java.util.HashMap;

//This class is for managing contacts (add, delete, and update)
public class ContactService {

	// HashMap is used to keep all the contacts
    // The key is the contactId, and the value is the Contact object
    private HashMap<String, Contact> contacts = new HashMap<>();
    
    // This method adds a new contact
    // It will only add if the contactId does not already exist
    public boolean addContact(Contact contact) {
        // Checking if the contactId already exists
        if (contacts.containsKey(contact.getContactId())) {
            return false; // Contact already exists, do not add
        }
        // Adding the new contact
        contacts.put(contact.getContactId(), contact);
        return true; // successfully added
    }
    
    // This method deletes a contact using contactId
    public boolean deleteContact(String contactId) {
        if (contacts.containsKey(contactId)) {
            contacts.remove(contactId); // remove the contact
            return true; // successfully deleted
        }
        return false; // contact not found
    }
    
    // This method updates the contact details
    // The contactId cannot be changed
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactId)) {
            Contact contactToUpdate = contacts.get(contactId);

            // Will only update if new values are not null or empty
            if (firstName != null && !firstName.isEmpty()) {
                contactToUpdate.setFirstName(firstName);
            }
            if (lastName != null && !lastName.isEmpty()) {
                contactToUpdate.setLastName(lastName);
            }
            if (phone != null && !phone.isEmpty()) {
                contactToUpdate.setPhone(phone);
            }
            if (address != null && !address.isEmpty()) {
                contactToUpdate.setAddress(address);
            }

            return true; // update successful
        }
        return false; // contact not found
    }

}