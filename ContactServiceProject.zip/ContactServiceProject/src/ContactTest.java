import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
//This class tests the Contact class
public class ContactTest {

// This test checks if a contact is created the right way
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("E458", "Elmo", "Monster", "2125556789", "150th Sesame Street");

        assertEquals("E458", contact.getContactId());
        assertEquals("Elmo", contact.getFirstName());
        assertEquals("Monster", contact.getLastName());
        assertEquals("2125556789", contact.getPhone());
        assertEquals("150th Sesame Street", contact.getAddress());
    }

 // This test checks if we can change the contact details with setters
    @Test
    public void testSetters() {
    	// Starting with Dora's info
        Contact contact = new Contact("D456", "Dora", "Explora", "5512345678", "5 Jungle Trail");

     // Changing Dora to Swiper with new details
        contact.setFirstName("Swiper");
        contact.setLastName("Fox");
        contact.setPhone("3318815723"); 
        contact.setAddress("99 Sneaky Ln");

     // Making sure the values are updated correctly
        assertEquals("Swiper", contact.getFirstName());
        assertEquals("Fox", contact.getLastName());
        assertEquals("3318815723", contact.getPhone());
        assertEquals("99 Sneaky Ln", contact.getAddress());
    }
    
 // This test checks that the contactId must not be null or over 10 characters
    @Test
    public void testInvalidContactId() {
        // Null contactId
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Test", "User", "1234567890", "Test Street");
        });

        // Too long contactId
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("TESTING_LONG_ID_12345", "Test", "User", "1234567890", "Test Street");
        });
    }
    
 // This test checks that the first name must not be null or over 10 characters
    @Test
    public void testInvalidFirstName() {
        // Null firstName
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X003", null, "User", "1234567890", "Test Street");
        });

        // Too long firstName
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X004", "SuperLongFirstName", "User", "1234567890", "Test Street");
        });
    }
    
 // This test checks that the last name must not be null or over 10 characters
    @Test
    public void testInvalidLastName() {
        // Null lastName
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X005", "Test", null, "1234567890", "Test Street");
        });

        // Too long lastName
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X006", "Test", "SuperLongLastName", "1234567890", "Test Street");
        });
    }
    
    // This test checks that the phone numbers must be 10 digits
    @Test
    public void testInvalidPhone() {
        // Too short (should fail)
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X001", "Test", "User", "12345", "Test Street");
        });

        // Null (should fail)
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X002", "Test", "User", null, "Test Street");
        });
    }
    
 // This test checks that the address must not be null or too long
    @Test
    public void testInvalidAddress() {
        // Null address
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X007", "Test", "User", "1234567890", null);
        });

        // Too long address
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("X008", "Test", "User", "1234567890", "12345 SUPER LONG ADDRESS IN THE SMALL TOWN OF NOWHERE");
        });
    }
}